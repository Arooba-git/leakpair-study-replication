/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
  return 'http://localhost:8000/';
}

// action where you suspect the memory leak might be happening
async function action(page) {
  const handles2 =  await page.$$('a[href="/huge-document"]');
  handles2[0].evaluate((h)=>{h.click()})

  const handles3 =  await page.$$('a[href="/markdown-shortcuts"]');
  handles3[0].evaluate((h)=>{h.click()});

  const handles4 =  await page.$$('a[href="/mentions"]');
  handles4[0].evaluate((h)=>{h.click()});

  const handles5 =  await page.$$('a[href="/tables"]');
  handles5[0].evaluate((h)=>{h.click()})

  const handles6 =  await page.$$('a[href="/images"]');
  handles6[0].evaluate((h)=>{h.click()})

  const handles7 =  await page.$$('a[href="/inlines"]');
  handles7[0].evaluate((h)=>{h.click()});

  const handles8 =  await page.$$('a[href="/search-highlighting"]');
  handles8[0].evaluate((h)=>{h.click()});

  const handles9 =  await page.$$('a[href="/placeholder"]');
  handles9[0].evaluate((h)=>{h.click()})
}

// how to go back to the state before actionw
async function back(page) {
  const handles =  await page.$$("a[href='/']");
  handles[0].evaluate((h)=>{h.click()});
}

module.exports = {action, back, url, repeat:() => 10};
