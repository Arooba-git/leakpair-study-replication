/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */


function url() {
  return 'http://localhost:4200/';
}

// action where you suspect the memory leak might be happening
async function action(page) {
  const themepicker  =  await page.$('button[aria-label="Select a theme"]');
  themepicker.evaluate((h)=>{h.click()});

  const theme = await page.$x("//span[contains(., 'Indigo & Pink')]");
  theme[0].evaluate((h)=>{h.click()});

  const matitems =  await page.$$('mat-nav-list a'); //foreach
  for (const item of matitems) {
    item.evaluate((h)=>{h.click()});

    const body =  await page.$('.docs-component-viewer');
    body.evaluate((h)=>{h.click()});
  }

  const cdk =  await page.$('a[href="/cdk"]');
  cdk.evaluate((h)=>{h.click()});

  const guides =  await page.$('a[href="/guides"]');
  guides.evaluate((h)=>{h.click()});

  const home =  await page.$('img[alt="angular"]');
  home.evaluate((h)=>{h.click()});
}

// how to go back to the state before actionw
async function back(page) {
    const home =  await page.$('img[alt="angular"]');
    home.evaluate((h)=>{h.click()});
}

module.exports = {action, back, url, repeat: () => 9};
