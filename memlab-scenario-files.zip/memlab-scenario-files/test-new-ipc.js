/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
  return 'http://localhost:3000/';
}

// action where you suspect the memory leak might be happening
async function action(page) {
  const navitems =  await page.$$('.text-uppercase.nav-link');
  console.log('navitems.length', navitems.length);
  for (const navitem of navitems) {
    const id = await navitem.evaluate((h)=>h.getAttribute('id'));
    console.log('navitem id:', id);
  
    if (id === 'navItem-login / signup-0' || id && id.includes('modal')) {
      continue;
    }

    navitem.evaluate((h)=>{h.click()});

    const buttons =  await page.$$('.cr-content div');
    for (const btn of buttons) {
      const btnclass = await btn.evaluate((h)=>h.getAttribute('class'));
      console.log('btn id:', btnclass);

      btn.evaluate((h)=>{h.click()});
    }
  }
}

// how to go back to the state before actionw
async function back(page) {
    const handles =  await page.$$('#navItem-dashboard-0');
    handles[0].evaluate((h)=>{h.click()});
}

function repeat() {
  return 5
}

module.exports = {action, back,  url, repeat};
