/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */


function url() {
  return 'http://localhost:3000/';
}

// action where you suspect the memory leak might be happening
async function action(page) {
  const inputs =  await page.$$('input[type="checkbox"]');
  for(const input of inputs) {
    input.evaluate((h)=>{h.click()});
  }

  const buttons =  await page.$$('button');
  for(const btn of buttons) {
    btn.evaluate((h)=>{h.click()});
  }

  const image =  await page.$('#image-button');
  image.evaluate((h)=>{h.click()});

  const imagebuttons = await page.$$('.mv-toolbar button');
  for(const btn of imagebuttons) {
    btn.evaluate((h)=>{h.click()});
  }
}

// how to go back to the state before actionw
async function back(page) {
  // const handles12 =  await page.$$('a[href="/"]');
  // handles12[0].evaluate((h)=>{h.click()});
}

module.exports = {url, action, back, repeat: () => 1};
