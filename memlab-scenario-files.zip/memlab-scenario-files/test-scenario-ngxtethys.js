




/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */


function url() {
  return 'http://localhost:8888/';
}

// action where you suspect the memory leak might be happening
async function action(page) {
    await page.waitForSelector('.nav a[href="/docs"]', {
  	    visible: true,
    });

    const docs =  await page.$('.nav a[href="/docs"]');
    docs.evaluate((h)=>{h.click()});

    const docItems =  await page.$$('.item-content .item-content-title');
    for (const doc of docItems) {
        doc.evaluate((h)=>{h.click()});
    }

    const design =  await page.$('.nav a[href="/design"]');
    design.evaluate((h)=>{h.click()});

    const docItems2 =  await page.$$('.item-content .item-content-title');
    for (const doc of docItems2) {
        doc.evaluate((h)=>{h.click()});
    }


    const components =  await page.$('.nav a[href="/components"]');
    components.evaluate((h)=>{h.click()});
    const componentItems =  await page.$$('.item-content .item-content-title');
    for (const component of componentItems) {
        component.evaluate((h)=>{h.click()});

        const tabs =  await page.$$('.dg-tab-links a');
        for (const tab of tabs) {
            tab.evaluate((h)=>{h.click()});
        }

    }


    const cdk =  await page.$('.nav a[href="/cdk"]');
    cdk.evaluate((h)=>{h.click()});
    const cdkItems =  await page.$$('.item-content .item-content-title');
    for (const cdkitem of cdkItems) {
        cdkitem.evaluate((h)=>{h.click()});

        const tabs =  await page.$$('.dg-tab-links a');
        for (const tab of tabs) {
            tab.evaluate((h)=>{h.click()});
        }

    }

    const backtobtn =  await page.$('.logo');
    backtobtn.evaluate((h)=>{h.click()});
}

// how to go back to the state before actionw
async function back(page) {
    const backtobtn =  await page.$('.logo');
    backtobtn.evaluate((h)=>{h.click()});
}

module.exports = {action, back, url, repeat: () => 10 };

