/* eslint-disable prettier/prettier */
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */


function url() {
  return 'http://localhost:8002/toolbar-visiblity-demo-nav-link';
}

// action where you suspect the memory leak might be happening
async function action(page) {

        
    const menuitems = await page.$$('.pf-c-nav__list a');
    for (const item of menuitems) {
        const itemid = await item.evaluate((h)=>h.getAttribute('id')); 
        console.log('\n\nitemID', itemid);

        if (itemid === 'button-demo-nav-item-link') {
            continue
        }
        item.evaluate((h)=>{h.click()});

        await page.waitForSelector('#ts-demo-app-page-id', {
            visible: true,
        });
        const framebuttons =  await page.$$('#ts-demo-app-page-id button');
        for (const btn of framebuttons) {
            const btnID = await btn.evaluate((h)=>h.getAttribute('id')); 
            console.log('btnID', btnID);

            // if (btnID === 'normal-btn-2') {
            //     continue
            // }
            btn.evaluate((h)=>{h.click()});
        }
    }
}

// how to go back to the state before actionw
async function back(page) {
    const toolbar =  await page.$('a[href="/toolbar-visiblity-demo-nav-link"]');
    toolbar.evaluate((h)=>{h.click()});
}

module.exports = {action, back, url, repeat: () => 9};
