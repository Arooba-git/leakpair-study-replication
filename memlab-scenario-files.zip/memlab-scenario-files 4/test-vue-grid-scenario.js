/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
    return 'http://localhost:8080/';
}

// action where you suspect the memory leak might be happening
async function action(page) {
    const buttons = await page.$$('#content button');
    for (const btn of buttons) {
        btn.evaluate(h => { h.click();});
    }

    const checkboxes = await page.$$('input[type="checkbox"]');
    for (const checkbox of checkboxes) {
        checkbox.evaluate(h => { h.click(); });
    }

    const numbers = await page.$$('input[type="number"]');
    for (const number of numbers) {
        number.evaluate(h => { h.value = "12" });
    }
}

// how to go back to the state before actionw
async function back(page) {
    const btn = await page.$$('#content button');
    btn[0].evaluate(h => { h.click(); });
}

module.exports = { url, action, back, repeat: () => 9 };
