/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
  return 'http://localhost:3000/';
}

// action where you suspect the memory leak might be happening
async function action(page) {
  await page.waitForSelector('header a[href="/docs/components"]', {
    visible: true
  })

  const docs = await page.$('header a[href="/docs/components"]')
  await docs.evaluate((h) => { h.click() })

  await page.waitForSelector('.bd-sidenav a', {
    visible: true
  })

  const links = await page.$$('.bd-sidenav a');
  console.log('\n\nlinks.length', links.length);
  const clickPromises = [];

  // for (const link of navLinks) {
  //   await link.evaluate(async (h) => {
  //     console.log('\n\nh.getAttribute(href)', h.getAttribute('href'));
  //     if (
  //       h.getAttribute('href').includes('components') &&
  //       !h.getAttribute('href').startsWith('http')
  //     ) {
  //       await h.click();
  //     }
  //   });

  for await (const [i, link] of links.entries()) {
    const hasPageNavigation = await link.evaluate(async (h) => {
      console.log('\n\nh?.getAttribute(href)', h?.getAttribute('href'));
      if (h.getAttribute('href').includes('components') &&
        !h.getAttribute('href').startsWith('http')) {
        return false;
      }
      return true;
    }, link); // Pass link as the second argument to link.evaluate()

    console.log('hasPageNavigation', hasPageNavigation);

    if (!hasPageNavigation) {
      clickPromises.push(link);
    }
  }

  clickPromises.forEach(async (link) => {
    await link.evaluate(async (h) => {
      console.log('selected h?.getAttribute(href): ', h?.getAttribute('href'));
      await h.click();
    });

    const buttons = await page.$$('section button');
    console.log('buttons', buttons.length);
    for (const btn of buttons) {
      await btn.evaluate((h) => { h.click() });
    }

    const inputs = await page.$$('section input');
    console.log('buttons', buttons.length);
    for (const input of inputs) {
      await input.evaluate((h) => { h.value = "text" });
    }
  });
}

// how to go back to the state before actionw
async function back(page) {
  const home = await page.$('header a[href="/"]');
  home.evaluate((h) => { h.click() });
}

module.exports = { action, back, url, repeat: () => 9 };
