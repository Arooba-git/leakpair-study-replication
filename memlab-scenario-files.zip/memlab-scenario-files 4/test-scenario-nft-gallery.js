/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */


function url() {
  return 'http://localhost:3000/ahk/drops';
}

// action where you suspect the memory leak might be happening
async function action(page) {
  const div = await page.$$('__nuxt');
  console.log('\ndiv[0]', div[0]); // Log the content

  const sideNavLinks = await page.$$('body a');
  console.log('sideNavLinks', sideNavLinks.length);
  for (const link of sideNavLinks) {
    if (link.getAttribute('target') === '_blank' || link.getAttribute('href').toString().startsWith('http')) {
      continue
    }

    link.evaluate((h) => { h.click() });

    const inputs = await page.$$('input');
    console.log('inputs', inputs.length);
    for (const inp of inputs) {
      btn.evaluate((h) => { h.value = "1234" });
    }

    const buttons = await page.$$('button');
    console.log('buttons', buttons.length);
    for (const btn of buttons) {
      if (link.getAttribute("target") === '_blank' || link.getAttribute('href').toString().startsWith('http')) {
        continue
      }

      btn.evaluate((h) => { h.click() });
    }
  }
}

// how to go back to the state before actionw
async function back(page) {
  // console.log(page.url());
  // const handles12 = await page.$$('button');
  // console.log('\nhandles12', handles12);
  // handles12[0].evaluate((h) => { h.click() });
}

module.exports = { url, action, back, repeat: () => 9 };
