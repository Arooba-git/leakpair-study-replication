
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */


function url() {
  return 'http://localhost:8080/';
}

// action where you suspect the memory leak might be happening
async function action(page) {
  page.setRequestInterception(true);
  await page.waitForSelector('#room-input', {
    visible: true,
  });

  const input = await page.$('#room-input');
  input.evaluate((h)=>{h.value = 'test room name'});

  await page.waitForFunction('document.getElementById("room-input").value != ""');

  console.log(await page.evaluate((x) => x.value, input));

  const enterRoom = await page.$('#enter-room');
  enterRoom.evaluate((h) => { h.click(); });

  const go = await page.$('#enter-room');
  go.evaluate((h)=>{h.click()});

  await page.waitForSelector('a[href="/streamer"]', {
    visible: true,
  });

  const streamer = await page.$('a[href="/streamer"]');
  streamer.evaluate((h) => { h.click() });
}

// how to go back to the state before actionw
async function back(page) {
  // await page.waitForSelector('a[href="/"]', {
  //   visible: true,
  // });

  // const home = await page.$('a[href="/"]');
  // home.evaluate((h) => { h.click() });
  // page.goBack();
}

module.exports = { action, back, url, repeat: () => 9 };
