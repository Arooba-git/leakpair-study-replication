/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
    return 'http://localhost:3000/2023/en-us';
}

// action where you suspect the memory leak might be happening
async function action(page) {
    await page.waitForXPath("//div[contains(., 'About')]", {
        visible: true
    })

    const aboutMenu = await page.$x("//div[contains(., 'About')]");
    aboutMenu[0].evaluate((h) => {
        h.click()
    })
    const taiwan = await page.$('a[href="/2023/en-us/about"]')
    await taiwan.evaluate((h) => {
        h.click()
    })

    aboutMenu[0].evaluate((h) => {
        h.click()
    })
    const his = await page.$('a[href="/2023/en-us/about/history"]')
    await his.evaluate((h) => {
        h.click()
    })

    aboutMenu[0].evaluate((h) => {
        h.click()
    })
    const comm = await page.$('a[href="/2023/en-us/about/community"]')
    await comm.evaluate((h) => {
        h.click()
    })

    aboutMenu[0].evaluate((h) => {
        h.click()
    })
    const cond = await page.$('a[href="/2023/en-us/about/code-of-conduct"]')
    await cond.evaluate((h) => {
        h.click()
    })

    let prevHeight = -1;
    const maxScrolls = 100;
    let scrollCount = 0;
    while (scrollCount < maxScrolls) {
        // Scroll to the bottom of the page
        await page.evaluate('window.scrollTo(0, document.body.scrollHeight)');
        // Wait for page load
        await page.waitForTimeout(1000);
        // Calculate new scroll height and compare
        const newHeight = await page.evaluate('document.body.scrollHeight');
        // eslint-disable-next-line eqeqeq
        if (newHeight == prevHeight) {
            break;
        }
        prevHeight = newHeight;
        scrollCount += 1;
    }
}

// how to go back to the state before actionw
async function back(page) {
    const home = await page.$('header a[href="/2023/en-us"]');
    home.evaluate((h) => {
        h.click()
    })
}

module.exports = { action, back, url, repeat: () => 9 };
