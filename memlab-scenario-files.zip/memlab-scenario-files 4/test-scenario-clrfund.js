/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
  return 'http://localhost:8080/#/';
}

// action where you suspect the memory leak might be happening
async function action(page) {
  const howitworks = await page.$('.hero-content .btn-white');
  howitworks.evaluate(async (h) => {await h.click()});

  const app = await page.$('a[href="#/projects"]');
  app.evaluate(async (h) => { await h.click() });

  const filter = await page.$('.filter-btn');
  filter.evaluate(async (h) => { await h.click() });
  const categories = await page.$$('.category-btn');
  for (const category of categories) {
    category.evaluate(h => { h.click(); });
  }

  const join = await page.$('a[href="#/join"]');
  join.evaluate(h => { h.click(); });

  const wallet = await page.$('.wallet-widget .app-btn');
  wallet.evaluate(h => { h.click(); });

  const close = await page.$('img[src="img/close.2aa2d96f.svg"]');
  close.evaluate(h => { h.click(); });

  const backtoprojects = await page.$('a[href="#/projects"]');
  backtoprojects.evaluate(h => { h.click(); });

  const help = await page.$('.help-dropdown');
  help.evaluate(h => { h.click(); });

  const dropdowns = await page.$$('.dropdown-item a');
  for (const ditem of dropdowns) {
    const hasoUTofPageNavigation = await ditem.evaluate((h) => {
      return h.getAttribute('href').startsWith('http')
    })

    if (hasoUTofPageNavigation) {
      continue;
    }

    ditem.evaluate(h => { h.click(); });
  }
}

// how to go back to the state before actionw
async function back(page) {
  const btn = await page.$$('a[href="#/"]');
  btn[0].evaluate(h => { h.click(); });
}

module.exports = { action, back, url, repeat: () => 9 };
