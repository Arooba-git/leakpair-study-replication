



// wait for

/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
  return 'http://localhost:5173/';
}

// action where you suspect the memory leak might be happening
async function action(page) {
  const docs = await page.$x("//span[contains(., 'Docs ')]");
  docs[0].evaluate(h => {
    h.click();
  });

  const examplemenu = await page.$('a[href="/examples/"]');
  examplemenu.evaluate(h => {
    h.click();
  });

  const examples = await page.$$('.group a')

  for (const example of examples) {
    example.evaluate(h => {
      h.click();
    });

    await page.waitForSelector('.editor', {
  	    visible: true,
    });
  }

  const api = await page.$('a[href="/api/"]');
  api.evaluate(h => {
    h.click();
  });

  const sponsor = await page.$('a[href="/sponsor/"]');
  sponsor.evaluate(h => {
    h.click();
  });

  const partner = await page.$('a[href="/partners/"]');
  partner.evaluate(h => {
    h.click();
  });
}

// how to go back to the state before actionw
async function back(page) {
  const handles12 = await page.$$('a[href="/"]');
  handles12[0].evaluate(h => {
    h.click();
  });
}

module.exports = { action, back, url, repeat: () => 9 };
