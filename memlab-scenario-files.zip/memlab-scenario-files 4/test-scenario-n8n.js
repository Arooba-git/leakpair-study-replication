



/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
	return 'http://localhost:5678/workflows'
}

// action where you suspect the memory leak might be happening
async function action(page) {
	const menuitems = await page.$$('.el-menu .el-menu-item')
	console.log('menuitems', menuitems.length);
	for (const menuitem of menuitems) {
		// const hasoUTofPageNavigation = await link.evaluate((h) => {
		// 	console.log("h.getAttribute('href')", h.getAttribute('href'));
		// 	return h.getAttribute('href').startsWith('http') || h.getAttribute('href').startsWith('/project/info/think-vuele');
		// })

		// if (hasoUTofPageNavigation) {
		// 	continue
		// }

		menuitem.evaluate((h) => { h.click()});


		const inputs = await page.$$('#content input');
		console.log("inputs", inputs.length);
		for (const input of inputs) {
			input.evaluate((h) => { h.click() });
		}


		const spans = await page.$$('#content span');
		console.log("spans", spans.length);
		for (const span of spans) {
			span.evaluate((h) => { h.click() });
		}


		const buttons = await page.$$('#content button');
		console.log("buttons", buttons.length);
		for (const button of buttons) {
			button.evaluate((h) => { h.click() });
		}
	}
}

// how to go back to the state before actionw
async function back(page) {
	const home = await page.$('#workflows')
	home.evaluate((h) => {
		h.click()
	})
}

module.exports = { action, back, url, repeat: () => 9 }

