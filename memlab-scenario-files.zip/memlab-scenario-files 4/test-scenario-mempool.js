/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */


function url() {
  return 'http://localhost:4200';
}

// action where you suspect the memory leak might be happening
async function action(page) {
    const timetoggle =  await page.$$('.time-toggle');
    timetoggle[0].evaluate((h)=>{h.click()});

     const mining1 =  await page.$$('a[href="/mining"]');
    mining1[0].evaluate((h)=>{h.click()});

     const difficulty1 =  await page.$$('a[href="/graphs/mining/hashrate-difficulty#1y"]');
    difficulty1[0].evaluate((h)=>{h.click()});

    const mining2 =  await page.$$('a[href="/mining"]');
    mining2[0].evaluate((h)=>{h.click()});

     const blocks =  await page.$$('a[href="/blocks"]');
    blocks[0].evaluate((h)=>{h.click()});

    const graphs =  await page.$$('a[href="/graphs"]');
    graphs[0].evaluate((h)=>{h.click()});

    const datespan =  await page.$$('div[name="radioBasic"] label');
    for (let i=0; i<9; i++) {
      datespan[i].evaluate((h)=>{h.click()});
    }

    const dropdownfees =  await page.$$('#dropdownFees');
    dropdownfees[0].evaluate((h)=>{h.click()});


    const graphmempool1 =  await page.$$('#dropdownBasic1');
    graphmempool1[0].evaluate((h)=>{h.click()});

    const miningPools =  await page.$$('a[href="/graphs/mining/pools"]');
    miningPools[0].evaluate((h)=>{h.click()});

    const graphmempool2 =  await page.$$('#dropdownBasic1');
    graphmempool2[0].evaluate((h)=>{h.click()});

    const dominance =  await page.$$('a[href="/graphs/mining/pools-dominance"]');
    dominance[0].evaluate((h)=>{h.click()});

    const graphmempool3 =  await page.$$('#dropdownBasic1');
    graphmempool3[0].evaluate((h)=>{h.click()});
    
    const difficulty =  await page.$$('a[href="/graphs/mining/hashrate-difficulty"]');
    difficulty[0].evaluate((h)=>{h.click()});

    const graphmempool4 =  await page.$$('#dropdownBasic1');
    graphmempool4[0].evaluate((h)=>{h.click()});
    
    const blockfeerates =  await page.$$('a[href="/graphs/mining/block-fee-rates"]');
    blockfeerates[0].evaluate((h)=>{h.click()});

    page.waitForTimeout(30000);

    const graphmempool5 =  await page.$$('#dropdownBasic1');
    graphmempool5[0].evaluate((h)=>{h.click()});

    const blockfees =  await page.$$('a[href="/graphs/mining/block-fees"]');
    blockfees[0].evaluate((h)=>{h.click()});
    
    const graphmempool6 =  await page.$$('#dropdownBasic1');
    graphmempool6[0].evaluate((h)=>{h.click()});

    const rewards =  await page.$$('a[href="/graphs/mining/block-rewards"]');
    rewards[0].evaluate((h)=>{h.click()});
    
    const graphmempool7 =  await page.$$('#dropdownBasic1');
    graphmempool7[0].evaluate((h)=>{h.click()});

    const weights =  await page.$$('a[href="/graphs/mining/block-sizes-weights"]');
    weights[0].evaluate((h)=>{h.click()});
    
    const graphmempool8 =  await page.$$('#dropdownBasic1');
    graphmempool8[0].evaluate((h)=>{h.click()});    

    const prediction =  await page.$$('a[href="/graphs/mining/block-prediction"]');
    prediction[0].evaluate((h)=>{h.click()});

    const docs =  await page.$$('a[href="/docs"]');
    docs[0].evaluate((h)=>{h.click()});

    const issues =  await page.$$('a[href="/docs/faq#address-lookup-issues"]');
    issues[0].evaluate((h)=>{h.click()});

    const firstmempool =  await page.$$('a[href="/mempool-block/0"]');
    firstmempool[0].evaluate((h)=>{h.click()});

    page.goBack();

    await page.waitForSelector('a[href="/terms-of-service"]', {
      visible: true,
    });

    const termsofservice  =  await page.$$('a[href="/terms-of-service"]');
    termsofservice[0].evaluate((h)=>{h.click()});

    const docs2 =  await page.$$('a[href="/docs"]');
    docs2[0].evaluate((h)=>{h.click()});

    await page.waitForSelector('a[href="/docs/api/rest"]', {
      visible: true,
    });

        const apirest =  await page.$$('a[href="/docs/api/rest"]');
    apirest[0].evaluate((h)=>{h.click()});


    const commonjs = await page.$x("//a[contains(., 'CommonJS')]");
    commonjs[0].evaluate((h)=>{h.click()});
    
    const esmodule = await page.$x("//a[contains(., 'ES Module')]");
    esmodule[0].evaluate((h)=>{h.click()});

    const websocket =  await page.$$('a[href="/docs/api/websocket"]');
    websocket[0].evaluate((h)=>{h.click()});

    const python = await page.$x("//a[contains(., 'Python')]");
    python[0].evaluate((h)=>{h.click()});

    await page.waitForSelector('a[href="/privacy-policy"]', {
      visible: true,
    });

    const privacypolicy =  await page.$$('a[href="/privacy-policy"]');
    privacypolicy[0].evaluate((h)=>{h.click()});

    const explore =  await page.$$('input[formcontrolname="searchText"]');
    explore[0].evaluate((h)=>{h.value = "text"});

    const exploresubmit =  await page.$$('button[type="submit"]');
    exploresubmit[0].evaluate((h)=>{h.click()});

    const about =  await page.$$('a[href="/about"]');
    about[0].evaluate((h)=>{h.click()});

    const home =  await page.$$('a[href="/"]');
    home[0].evaluate((h)=>{h.click()});

     const broadcasttransaction =  await page.$$('a[href="/tx/push"]');
    broadcasttransaction[0].evaluate((h)=>{h.click()});

    const broadcasttextarea =  await page.$$('textarea[formcontrolname="txHash"]');
    broadcasttextarea[0].evaluate((h)=>{h.click()});

    const submitBroadcast =  await page.$$('button[type="submit"]');
    submitBroadcast[0].evaluate((h)=>{h.click()});
}

// how to go back to the state before actionw
async function back(page) {
    const home =  await page.$$('a[href="/"]');
    home[0].evaluate((h)=>{h.click()});
}

module.exports = {action, back, url, repeat: () => 9};
