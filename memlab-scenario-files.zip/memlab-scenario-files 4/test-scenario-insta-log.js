/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */


function url() {
    return 'http://localhost:8081/login';
}

// action where you suspect the memory leak might be happening
async function action(page) {
    await page.waitForSelector('.slider-section__carousel__pagination__picker', {
        visible: true,
    });


    const sliders = await page.$$('.slider-section__carousel__pagination__picker');
    console.log('sliders', sliders.length);
    for (const slider of sliders) {
        slider.evaluate((h) => { h.click() });
    }

    const buttons = await page.$$('body button');
    console.log('buttons', buttons.length);
    for (const button of buttons) {
        button.evaluate((h) => { h.click() });
    }

    const links = await page.$$('body a');
    console.log('links', links.length);
    for (const link of links) {
        link.evaluate((h) => { h.click() });
    }

    const inputs = await page.$$('body input');
    console.log('input', inputs.length);
    for (const input of inputs) {
        input.evaluate((h) => { h.value = 'text' });
    }
}

// how to go back to the state before actionw
async function back(page) {
    const sliders = await page.$$('.slider-section__carousel__pagination__picker');
    sliders[0].evaluate((h) => { h.click() });
}


module.exports = { action, back, url, repeat: () => 9 };

