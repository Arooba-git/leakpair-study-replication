/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
    return 'http://localhost:8080/';
}

// action where you suspect the memory leak might be happening
async function action(page) {
    await page.waitForSelector('a[href="/documentation"]', {
        visible: true,
    });
    const doc = await page.$('a[href="/documentation"]')
    doc.evaluate((h) => {
        h.click()
    })


    await page.waitForSelector('.sidebar-menu a', {
        visible: true,
    });

    const links = await page.$$('.sidebar-menu a')
    console.log("links", links.length);
    var results = [];
    for (var i = 0; i < 10; i++) {
        var random = Math.floor((Math.random() * links.length) + 1);
        results.push(random);
    }

    for (let i = 0; i < results.length; i++) {
        const currentIndex = results[i];

        const hasOutofPageNavigation = await links[currentIndex]?.evaluate((h) => {
            return h.getAttribute('href').startsWith('http')
        })

        if (hasOutofPageNavigation) {
            continue;
        }

        links[currentIndex]?.evaluate((h) => {
            h.click()
        })

        const egbuttons = await page.$$('.example-section button');
        console.log("egbuttons", egbuttons.length);
        egbuttons[0]?.evaluate((h) => {
            h.click()
        })
    }
}

// how to go back to the state before actionw
async function back(page) {
const home = await page.$('a[href="/"]')
home.evaluate((h) => {
    h.click()
})
}

module.exports = { action, back, url, repeat: () => 9 }
