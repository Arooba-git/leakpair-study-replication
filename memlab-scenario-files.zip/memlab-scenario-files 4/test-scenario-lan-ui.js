/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
    return 'http://localhost:8081/#/'
}

// action where you suspect the memory leak might be happening
async function action(page) {
    const links = await page.$$('a')
    console.log("links", links.length);
    for (const link of links) {
        const hasoUTofPageNavigation = await link.evaluate((h) => {
            return h.getAttribute('href').startsWith('http')
        })

        console.log('\nhasoUTofPageNavigation', hasoUTofPageNavigation);
        if (hasoUTofPageNavigation) {
            continue;
        }

        link.evaluate((h) => {
            h.click()
        })

        const buttons = await page.$$('button');
        console.log("buttons", buttons.length);
        for (const btn of buttons) {
          const hasoUTofPageNavigation = await btn.evaluate((h) => {
            const anchorOfButton = h.querySelector('a')
            return anchorOfButton && anchorOfButton.getAttribute('href').startsWith('http')
          })

          if (hasoUTofPageNavigation) {
            continue
          }

          btn.evaluate((h) => {
              h.click()
          })
        }

        const icons = await page.$$('i');
        console.log("icons", icons.length);
        for (const ico of icons) {
            await ico.evaluate((h) => {
                h.click();
            })
        }
    }
}

// how to go back to the state before actionw
async function back(page) {
    const home = await page.$('a')
    home.evaluate((h) => {
        h.click()
    })
}

module.exports = { action, back, url, repeat: () => 9 }
