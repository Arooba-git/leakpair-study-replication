/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
    return 'http://localhost:5173/';
}

// action where you suspect the memory leak might be happening
async function action(page) {
  const tabs = await page.$$('.tab button');
  for await (const tab of tabs) {
    const hasPageNavigation = await tab.evaluate(async (h) => {
      console.log('\n\nh?.getAttribute(href)', h?.getAttribute('href'));
      return (h?.getAttribute('href')?.startsWith('http') || h?.getAttribute('href')?.startsWith('#usage-react') || h?.getAttribute('href')?.startsWith('#usage-disable') || h?.getAttribute('href')?.startsWith('usage-disable')) 
    }); // Pass link as the second argument to link.evaluate()

    console.log('hasPageNavigation', hasPageNavigation);
    
    if (!hasPageNavigation) {
      continue
    }

    tab.evaluate(async (h) => {
        await h.click()
    });

    const panelButtons = await page.$$('.tab-panel button');
    for (const btn of panelButtons) {
    const btnhasoUTofPageNavigation = await btn.evaluate((h) => {
        const anchorOfButton = h.querySelector('a')
        return anchorOfButton && anchorOfButton.getAttribute('href')?.startsWith('http')
    })

    console.log('(btnhasoUTofPageNavigation', btnhasoUTofPageNavigation);

    if (btnhasoUTofPageNavigation) {
        continue
    }

    btn.evaluate(h => { h.click(); });
    }

    const inputs = await page.$$('.tab-panel input');
    for (const input of inputs) {
        input.evaluate(h => {input.value = "test" });
    }
  }
}

// how to go back to the state before actionw
async function back(page) {
    const btn = await page.$$('.tab button');
    btn[0].evaluate(h => { h.click(); });
}

module.exports = { action, back, url, repeat: () => 9 };
