/* eslint-disable no-restricted-syntax */
/* eslint-disable prettier/prettier */
/* eslint-disable no-await-in-loop */
/* eslint-disable no-unused-vars */
/* eslint-disable no-shadow */
/* eslint-disable no-undef */
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */


function url() {
  return 'http://localhost:6006/?path=/story/styleguide-buttons--default-story';
}

// action where you suspect the memory leak might be happening
async function action(page) {
  await page.waitForSelector('button[data-nodetype="group"]', {
    visible: true,
  });

  const groups = await page.$$('button[data-nodetype="group"]');
  for (const group of groups) {
    group.evaluate((h) => { h.click() });


    await page.waitForSelector('button[data-nodetype="component"]', {
      visible: true,
    });

    const buttons = await page.$$('button[data-nodetype="component"]');
    for (const button of buttons) {
      button.evaluate((h) => { h.click() });
    }

    // await page.waitForSelector('a[data-nodetype="story"]', {
    //   visible: true,
    // });
    const stories = await page.$$('a[data-nodetype="story"]');

    await page.waitForSelector('#storybook-preview-iframe', { timeout: 30000 });
    const iframeHandle = await page.$('#storybook-preview-iframe');
    const frame = await iframeHandle.contentFrame();
    await frame.waitForSelector('body');

    for (const story of stories) {
      story.evaluate((h) => { h.click() });

      const inputs = await frame.$$('inputs');
      for (const input of inputs) {
        input.evaluate((h) => { h.click() });
      }

      const buttons = await frame.$$('button');

      for (const button of buttons) {
        const hasoUTofPageNavigation = button.evaluate((h) => {
          const anchorOfButton = h.querySelector('a')
          return anchorOfButton && anchorOfButton.getAttribute('href').startsWith('http')
        })

        if (hasoUTofPageNavigation) {
          continue
        }

        link.evaluate((h) => {
          h.click()
        })

        btn.evaluate((h) => {
          h.click()
        })

        button.evaluate((h) => { h.click() });
      }
    }
  }
};

// how to go back to the state before actionw
async function back(page) {
  const alert = await page.$('#styleguide-buttons');
  alert.evaluate((h)=>{h.click()});
}

module.exports = { action, back, url, repeat: () => 9 };
