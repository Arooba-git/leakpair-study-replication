/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
    return 'http://0.0.0.0:8085/#/en-US'
}

// action where you suspect the memory leak might be happening
async function action(page) {
    await page.waitForSelector('.nav-item a[href="#/en-US/component"]', {
        visible: true,
    });
    const component = await page.$('.nav-item a[href="#/en-US/component"]')
    component.evaluate((h) => { h.click() })


    await page.waitForXPath("//a[contains(., 'Carousel')]", {
        visible: true,
    });

    const rtl = await page.$x("//a[contains(., 'Carousel')]");
    rtl[0].evaluate(h => { h.click();});

    const buttons = await page.$$('.source button');
    console.log("buttons", buttons.length);
    for (const btn of buttons) {
        const btnhasoUTofPageNavigation = btn.evaluate((h) => {
            const anchorOfButton = h.querySelector('a')
            return anchorOfButton && anchorOfButton.getAttribute('href').startsWith('http')
        })

        if (btnhasoUTofPageNavigation) {
            continue
        }

        btn.evaluate((h) => {
            h.click()
        })
    }
}

// how to go back to the state before actionw
async function back(page) {
    const home = await page.$('a[href="#/en-US"]')
    home.evaluate((h) => {
        h.click()
    })
}

module.exports = { action, back, url, repeat: () => 9 }
