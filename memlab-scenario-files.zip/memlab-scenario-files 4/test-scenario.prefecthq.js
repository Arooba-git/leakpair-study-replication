/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
    return 'http://localhost:8080/'
}

// action where you suspect the memory leak might be happening
async function action(page) {
    const burger = await page.$('.v-app-bar__nav-icon');
    burger.evaluate((h) => { h.click() });
    const links = await page.$$('.v-list .v-list-item')
    console.log("links", links.length);
    for (const link of links) {
        // ''
        // const hasoUTofPageNavigation = await link.evaluate((h) => {
        //     console.log("h.getAttribute('href')", h.getAttribute('href'));
        //     return h.getAttribute('href').startsWith('http') || h.getAttribute('href').startsWith('/project/info/think-vuele');
        // })

        // if (hasoUTofPageNavigation) {
        //     continue
        // }

        link.evaluate((h) => {
            h.click()
        })

        const divbuttons = await page.$$('.v-main__wrap div[role="button"]');
        console.log("divbuttons", divbuttons.length);
        for (const divbutton of divbuttons) {
            divbutton.evaluate((h) => { h.click()})
        }

        const buttons = await page.$$('.v-main__wrap button');
        console.log("buttons", buttons.length);
        for (const btn of buttons) {
            btn.evaluate((h) => { h.click() })
        }

        
        const burger = await page.$('.v-app-bar__nav-icon');
        burger.evaluate((h) => { h.click() });
    }
}

// how to go back to the state before actionw
async function back(page) {
    const burger = await page.$('.v-app-bar__nav-icon');
    burger.evaluate((h) => { h.click() });
    const home = await page.$('a[href="/home"]')
    home.evaluate((h) => {
        h.click()
    })
}

module.exports = { action, back, url, repeat: () => 9 }
