/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */


function url() {
    return 'http://localhost:8080/#/map?lang=en&lat=46.815&lon=8.225&z=7&bgLayer=ch.swisstopo.pixelkarte-farbe&topic=ech&layers=ch.astra.wanderland-sperrungen_umleitungen,f;ch.swisstopo.swisstlm3d-wanderwege,f;ch.bav.haltestellen-oev,f;ch.bfs.gebaeude_wohnungs_register,f;ch.swisstopo.zeitreihen@time=18641231,f';
}

const getRandomNumbers = (items) => {
    const results = [];
    for (var it = 0; it < 100; it++) {
        var random = Math.floor((Math.random() * items.length) + 1);
        results.push(random);
    }
    return results;

}
// action where you suspect the memory leak might be happening
async function action(page) {
    await page.waitForSelector('body a', {
        visible: true,
    });

    const links = await page.$$('body a');
    // let indicesList = getRandomNumbers(links.length);
    console.log('links.length', links.length);

    for (let i = 0; i < links.length; i++) {
        // const currentIndex = indicesList[i];
        const hasOutofPageNavigation = await links[i]?.evaluate((h) => {
            return h.getAttribute('href')?.startsWith('http')
        })

        if (hasOutofPageNavigation) {
            continue;
        }

        links[i]?.evaluate((h) => {
            h.click()
            
        });
    }

    await page.waitForTimeout(10000);

    const buttons = await page.$$('body button');
    let indicesList = getRandomNumbers(buttons.length);
    console.log('buttons.length', buttons.length);
    for (let i = 0; i < indicesList.length; i++) {
        const currentIndex2 = indicesList[i];
        const hasoUTofPageNavigation = await buttons[currentIndex2]?.evaluate((h) => {
            const anchorOfButton = h.querySelector('a')
            return anchorOfButton && anchorOfButton.getAttribute('href')?.startsWith('http')
        })

        if (hasoUTofPageNavigation) {
            continue
        }

        buttons[currentIndex2]?.evaluate((h) => {
             h.click();
            
        });
    }

    await page.waitForTimeout(10000);

    const inputs = await page.$$('input');
    // indicesList = getRandomNumbers(inputs.length);
    console.log('inputs.length', inputs.length);
    for (let i = 0; i < inputs.length; i++) {
        // const currentIndex3 = inputs[i];
        inputs[i]?.evaluate((h) => { h.value = "text" });
    }
}

// how to go back to the state before actionw
async function back(page) {
    // const home = await page.$('img[src="/img/swiss-flag.2e156c76.svg"]');
    // home.evaluate((h) => { h.click() });
}

module.exports = { action, back, url, repeat: () => 9 };
