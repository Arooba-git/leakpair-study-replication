/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
    return 'http://localhost:5000/';
}

// action where you suspect the memory leak might be happening
async function action(page) {
    const links = await page.$$('a');
    for (const link of links) {
        link.evaluate(h => { h.click(); });
    }
}

// how to go back to the state before actionw
async function back(page) {
    const links = await page.$$('a');
    links[0].evaluate(h => { h.click(); });
    
}

module.exports = { url, action, back, repeat: () => 9 };
