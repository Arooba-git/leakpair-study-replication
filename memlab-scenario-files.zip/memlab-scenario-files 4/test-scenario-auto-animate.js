/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
  return 'http://localhost:3000/#installation';
}

// action where you suspect the memory leak might be happening
async function action(page) {
}

// how to go back to the state before actionw
async function back(page) {
  // const btn = await page.$$('a[href="#installation"]');
  // btn[0].evaluate(h => { h.click(); });
}

module.exports = { action, back, url, repeat: () => 9 };

// const links = await page.$$('.documentation a');
// console.log('\nlinks', links.length);
// for (const link of links) {
//   const hasoUTofPageNavigation = await link.evaluate((h) => {
//     return h.getAttribute('href').startsWith('http')
//   })

//   if (hasoUTofPageNavigation) {
//     continue;
//   }

//   link.evaluate(h => { h.click(); });
// }

// const buttons = await page.$$('button');
// console.log('\nbuttons', buttons.length);
// for (const btn of buttons) {
//   const btnhasoUTofPageNavigation = await btn.evaluate((h) => {
//     const anchorOfButton = h.querySelector('a')
//     return anchorOfButton && anchorOfButton.getAttribute('href').startsWith('http')
//   })

//   if (btnhasoUTofPageNavigation) {
//     continue
//   }

//   btn.evaluate(h => { h.click(); });
// }
