/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
    return 'http://localhost:8081/split';
}

// action where you suspect the memory leak might be happening
async function action(page) {
    await page.waitForSelector('nav a', {
        visible: true,
    });

    const docs = await page.$$('nav a');
    for (const menu of docs) {
        menu.evaluate((h) => { h.click() });

        const buttons = await page.$$('*:not(nav) > button');
        console.log('buttons', buttons.length);
        for (const btn of buttons) {
            btn.evaluate((h) => { h.click() });
        }

        const inputs = await page.$$('*:not(nav) > input');
        console.log('inputs', inputs.length);
        for (const input of inputs) {
            await input.evaluate((h) => {
                console.log('\nclass', h.getAttribute('class'));
                console.log('id', h.getAttribute('id'));
                if (h.getAttribute('class')  !== 'ivu-upload-input') {
                    h.value = "test"
                }
            });
        }
    }
}

// how to go back to the state before actionw
async function back(page) {
    const home = await page.$('a[href="/split"]');
    home.evaluate((h) => { h.click() });
}

module.exports = { action, back, url, repeat: () => 9 };
