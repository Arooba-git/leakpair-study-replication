/* eslint-disable no-var */
/* eslint-disable prettier/prettier */
/* eslint-disable no-undef */
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
    return 'http://localhost:8080/#/browse/mine?tc.mode=fixed&tc.startBound=1705057580650&tc.endBound=1705059410650&tc.timeSystem=utc&view=grid'
}

// action where you suspect the memory leak might be happening
async function action(page) {
    await page.waitForSelector('button', {
        visible: true,
    });
    const buttons = await page.$$('button')
    console.log("buttons", buttons.length);
    let results = [];
    for (var it = 0; it < 20; it++) {
        results = [];
        var random = Math.floor(Math.random() * buttons.length + 1);
        results.push(random);
    }

    for (let i = 0; i < results.length; i++) {
        const currentIndex = results[i];
        const hasoUTofPageNavigation = await buttons[currentIndex]?.evaluate((h) => {
            const anchorOfButton = h.querySelector('a')
            return anchorOfButton && anchorOfButton.getAttribute('href').startsWith('http')
        })

        console.log('\nhasoUTofPageNavigation', hasoUTofPageNavigation);
        if (hasoUTofPageNavigation) {
            continue;
        }

        buttons[currentIndex]?.evaluate((h) => {
            h.click()
        })



        const nestedbuttons = await page.$$('button');

        console.log("buttons", buttons.length);
        for (const nestedbtn of nestedbuttons) {
            const hasoUTofPageNavigation2 = await nestedbtn.evaluate((h) => {
                const anchorOfButton = h.querySelector('a')
                return anchorOfButton && anchorOfButton.getAttribute('href').startsWith('http')
            })

            if (hasoUTofPageNavigation2) {
                continue
            };

            nestedbtn.evaluate((h) => {
                h.click()
            })
        }
    }
}

// how to go back to the state before actionw
async function back(page) {
    const home = await page.$('button')
    home.evaluate((h) => {
        h.click()
    })
}

module.exports = { action, back, url, repeat: () => 9 }
