/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * @nolint
 * @oncall web_perf_infra
 */

function url() {
  return 'http://localhost:8089/#/zh-CN'
}

// action where you suspect the memory leak might be happening
async function action(page) {
  const links = await page.$$('a')
  console.log("links", links.length);
  for (const link of links) {
    const hasoUTofPageNavigation = await link.evaluate((h) => {
      console.log("h.getAttribute('href')", h.getAttribute('href'));
      return h.getAttribute('href').startsWith('http') || h.getAttribute('href').startsWith('/project/info/think-vuele');
    })

    if (hasoUTofPageNavigation) {
      continue
    }

    link.evaluate((h) => {
      h.click()
    })

    const buttons = await page.$$('button');
    console.log("buttons", buttons.length);
    for (const btn of buttons) {
      const hasoUTofPageNavigation = await link.evaluate((h) => {
        const anchorOfButton = h.querySelector('a')
        console.log('anchorOfButton', anchorOfButton);
        return anchorOfButton && anchorOfButton.getAttribute('href').startsWith('http')
      })

      if (hasoUTofPageNavigation) {
        continue;
      }

      btn.evaluate((h) => {
        h.click()
      })
    }
  }
}

// how to go back to the state before actionw
async function back(page) {
  const home = await page.$('a[href="#/zh-CN"]')
  home.evaluate((h) => {
    h.click()
  })
}

module.exports = { action, back, url, repeat: () => 9 }
